#!/bin/sh
/home/johanv/mail_program/programs/mailprog

