#!/usr/bin/python
import os
print """
 ___      ___       __       _____   _
|   \    /   |     /  \     |_   _| | |
| |\ \  / /| |    / /\ \      | |   | |
| | \ \/ / | |   / /__\ \     | |   | |
| |  \__/  | |  / ______ \   _| |_  | |____
|_|        | | /_/      \_\ |_____| |______|
"""

home = "/home/johanv/programs/mail"
#name = startmail(home)
while(True):
  os.system('clear')
  print """
============================
=               _____      =
= |\  /|   /\     |   |    =
= | \/ |  /__\    |   |    =
= |    | /    \ __|__ |___ =
=                          =
============================"""
  print "User:" #, name
  print "Mail:"
  #showmail(name,home)
"""
  print "==============================================="
  print "What do you want to do(1-5)?"
  print "1.Send a message to any user."
  print "2.Read a message in your inbox."
  print "3.Log out of your account."
  print "4.List all the users."
  print "5.exit."
  read choice
  cd
  case "$choice" in
    1) $home/mail_program/programs/sendmail "$name" "$home";;
    2) clear
       $home/mail_program/programs/checkmail "$name" "$home";;
    3) clear
       print `date`":	Logged out form $name" >> $home/mail_program/files/log.txt
       $home/mail_program/programs/startmail "$home"
       name=`cat $home/mail_program/files/name.txt`;;
    4) clear
       ls -1 $home/mail_program/users
       read a;;
    5) print `date`":	Logged out form $name" >> $home/mail_program/files/log.txt
       print `date`":	Exited" >> $home/mail_program/files/log.txt
       exit;;
  esac
done

"""

